//暴力程序
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int a,b,ans=0;
    cin>>a>>b;
    for(int i=1;i<=a;i++) ans++;
    for(int j=1;j<=b;j++) ans++;
    cout<<ans;
    return 0;
}