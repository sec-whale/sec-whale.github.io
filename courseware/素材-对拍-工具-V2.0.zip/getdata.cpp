//获得随机数据
#include<bits/stdc++.h>
using namespace std;

int main()
{
    //freopen("data.in","w",stdout);
    srand(time(0));
    //随机获得[2,100]之间的数字
    int a=rand()%99+2;
    int b=rand()%99+2;
    cout<<a<<' '<<b<<'\n';
    return 0;
}

