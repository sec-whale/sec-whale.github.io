#include<bits/stdc++.h>
using namespace std;

int main()
{
    //生成随机数，存入到data.in中
    system("getdata.exe >data.in");

    //运行暴力程序，从data.in读入数据<，把结果输出baoli.out>
    system("baoli.exe <data.in > baoli.out");

    //运行标准程序，从data.in读入数据<，把结果输出std.out
    system("std.exe <data.in >std.out");

    //比较两个文件，如果两个文件里数据相同返回0，不同返回1
    if(system("fc std.out baoli.out"))
    {
        cout<<"有数据不一样";
    }
    else
    {
        cout<<"对拍成功";
    }
    return 0;
}

