#include<bits/stdc++.h>
using namespace std;

int main()
{
    //生成随机数，存入到data.in中
    system("./getdata >data.in");

    //运行暴力程序，从data.in读入数据<，把结果输出baoli.out>
    system("./baoli <data.in > baoli.out");

    //运行标准程序，从data.in读入数据<，把结果输出std.out
    system("./std <data.in >std.out");

    //比较两个文件，如果两个文件里数据相同返回0，不同返回1
    if(system("diff std.out baoli.out"))
    {
        cout<<"有数据不一样";
    }
    else
    {
        cout<<"对拍成功";
    }
    return 0;
}

